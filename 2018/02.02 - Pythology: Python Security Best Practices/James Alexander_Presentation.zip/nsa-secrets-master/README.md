## Crypto Challenge

`Erzrzore gb qevax lbhe Binygvar!`

`Q29uZ3JhdHVsYXRpb25zISBIZXJlIGlzIGEgcmFuZG9tIGVhc3RlciBlZ2c6DQoNCmFIUjBjSE02THk5NWIzVjBkUzVpWlM5b1gyeDZaMjgzY0cxNmF3PT0=`


# nsa-secrets
Talk for Pythology Security Best Practices for February 2018

## To Run the Notebook
1. `pip install -r requirements.txt`
2. `jupyter notebook`
3. Run notebook from your default browser.

