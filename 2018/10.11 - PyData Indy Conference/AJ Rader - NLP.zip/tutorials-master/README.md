# tutorials
Repo for various Tutorials and Talks

Currently there is only one on Natural Language Processing (NLP) 

