from django.apps import AppConfig


class FfdbConfig(AppConfig):
    name = 'ffdb'
