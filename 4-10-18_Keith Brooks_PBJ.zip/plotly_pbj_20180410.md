
## Data Visualization with Plotly for Python
<img src='python-logo@2x.png' />


### What is a Choropleth map anyway???


```python
# Choropleth maps display data across geographical areas

```

<img src='national_cm.gif' />

### Ok, that is great to know...But, why do I care?

### Name your Enemy

#### Run, that guy with spreadsheets is coming
* Data without insight => foreign language to most people
* When we visualize data, the data remains the same we only see it differently
* Not all of us are great at processing data tables

<img src='rain_man.gif' />

#### Reasons to visualize data
   * Compare
   * Reveal Patterns
   * The goal is to gain insight!

### Why Now

#### Social Applications
* In 2017, Youtube users watched 4,146,600 videos every minute. 
<img src="data_never_sleeps.png"/>

## ["It deosn't mttaer in waht oredr the ltteers in a wrod are, the olny iprmoetnt tihng is taht the frist and lsat ltteer be at the rghit pclae. The rset can be a toatl mses and you can sitll raed it wouthit porbelm. Tihs is bcuseae the huamn mnid deos not raed ervey lteter by istlef, but the wrod as a wlohe."]

* src: https://www.mnn.com/lifestyle/arts-culture/stories/why-your-brain-can-read-jumbled-letters
* src: https://www.domo.com/blog/data-never-sleeps-5/

### Paint a picture of the promise land 

* So, how do we gain this insight?
	* Swarm Plots    
<img src='swarm_plot_tips.png' />    




* Heatmaps
<img src='passenger_volume.png' />


* Geographical maps

### Explain the obstacles 

#### Installs

Use the following to install libraries
 
 `
 pip install plotly
 `
 
 `
 pip install cufflinks
 `
 
 `
 pip install pandas
 `

#### Step (1) - Import necessary dependencies


```python
# Use imports and setup environment to work offline
import plotly.plotly as py
import plotly.graph_objs as go
import pandas as pd
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
```


```python
# Use init_notebook_mode to connect the Javascript to display the plots in the notebook
init_notebook_mode(connected=True)
```


<script>requirejs.config({paths: { 'plotly': ['https://cdn.plot.ly/plotly-latest.min']},});if(!window.Plotly) {{require(['plotly'],function(plotly) {window.Plotly=plotly;});}}</script>


#### Step (2) Import data


```python
# Import the sample dataset
df = pd.read_csv('2011_US_AGRI_Exports')

# display the top rows of the data frame
df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>code</th>
      <th>state</th>
      <th>category</th>
      <th>total exports</th>
      <th>beef</th>
      <th>pork</th>
      <th>poultry</th>
      <th>dairy</th>
      <th>fruits fresh</th>
      <th>fruits proc</th>
      <th>total fruits</th>
      <th>veggies fresh</th>
      <th>veggies proc</th>
      <th>total veggies</th>
      <th>corn</th>
      <th>wheat</th>
      <th>cotton</th>
      <th>text</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>AL</td>
      <td>Alabama</td>
      <td>state</td>
      <td>1390.63</td>
      <td>34.4</td>
      <td>10.6</td>
      <td>481.0</td>
      <td>4.06</td>
      <td>8.0</td>
      <td>17.1</td>
      <td>25.11</td>
      <td>5.5</td>
      <td>8.9</td>
      <td>14.33</td>
      <td>34.9</td>
      <td>70.0</td>
      <td>317.61</td>
      <td>Alabama&lt;br&gt;Beef 34.4 Dairy 4.06&lt;br&gt;Fruits 25.1...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>AK</td>
      <td>Alaska</td>
      <td>state</td>
      <td>13.31</td>
      <td>0.2</td>
      <td>0.1</td>
      <td>0.0</td>
      <td>0.19</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.6</td>
      <td>1.0</td>
      <td>1.56</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>Alaska&lt;br&gt;Beef 0.2 Dairy 0.19&lt;br&gt;Fruits 0.0 Ve...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>AZ</td>
      <td>Arizona</td>
      <td>state</td>
      <td>1463.17</td>
      <td>71.3</td>
      <td>17.9</td>
      <td>0.0</td>
      <td>105.48</td>
      <td>19.3</td>
      <td>41.0</td>
      <td>60.27</td>
      <td>147.5</td>
      <td>239.4</td>
      <td>386.91</td>
      <td>7.3</td>
      <td>48.7</td>
      <td>423.95</td>
      <td>Arizona&lt;br&gt;Beef 71.3 Dairy 105.48&lt;br&gt;Fruits 60...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>AR</td>
      <td>Arkansas</td>
      <td>state</td>
      <td>3586.02</td>
      <td>53.2</td>
      <td>29.4</td>
      <td>562.9</td>
      <td>3.53</td>
      <td>2.2</td>
      <td>4.7</td>
      <td>6.88</td>
      <td>4.4</td>
      <td>7.1</td>
      <td>11.45</td>
      <td>69.5</td>
      <td>114.5</td>
      <td>665.44</td>
      <td>Arkansas&lt;br&gt;Beef 53.2 Dairy 3.53&lt;br&gt;Fruits 6.8...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>CA</td>
      <td>California</td>
      <td>state</td>
      <td>16472.88</td>
      <td>228.7</td>
      <td>11.1</td>
      <td>225.4</td>
      <td>929.95</td>
      <td>2791.8</td>
      <td>5944.6</td>
      <td>8736.40</td>
      <td>803.2</td>
      <td>1303.5</td>
      <td>2106.79</td>
      <td>34.6</td>
      <td>249.3</td>
      <td>1064.95</td>
      <td>California&lt;br&gt;Beef 228.7 Dairy 929.95&lt;br&gt;Frui...</td>
    </tr>
  </tbody>
</table>
</div>



#### Step (3) Create Data Variable (Object)


```python
# Create data object with the dict() method

# colorscale = 'YIOrRd', --> This is the color for the geographical map elements
# locations = df['code'], --> This is the data for the state abbreviations
# locationmode = 'USA-states', --> This lets plotly know we want the US
# z = df['total exports'], --> This is the numerical value for each state element
# text = df['text'], --> This is the categorical value for each element
# colorbar = {'title': 'Millions USD'}, --> Title for right side bar
# marker = dict(line = dict(color = 'rgb(255,255,255)', width=2)) --> 

data = dict(type = 'choropleth',
           colorscale = 'YIOrRd',
           locations = df['code'],
           locationmode = 'USA-states',
           z = df['total exports'],
           text = df['text'],
           colorbar = {'title': 'Millions USD'},
           marker = dict(line = dict(color = 'rgb(255,255,255)', width=2))
           )
```

#### Step (4) Create Layout Variable (Object)


```python
# Create layout object with the dict() method

# scope argument refers to the geographical map of interest
# showlakes arguments turns on display for lakes
# lakecolor argument adjust the color of the lakes

layout = dict(title = '2011 US Agriculture Exports by State',
             geo = dict(scope = 'usa', showlakes=True, lakecolor='rgb(85,173,240)'))
```

#### Step (5) Plot Figure


```python
# Create Figure

choromap2 = go.Figure(data=[data], layout = layout)

# Use iplot() method to generate plot

#iplot(choromap2)
```

<img src='national_cm.gif' />

### Evidence - In the wild

* Credit: Emilia Petrisor
<img src='mri.gif' />

### Lessons Learned/ Helpful Tips

#### Lessons Learned:
* Learn various ways to communicate
* Analysis starts with good questions


#### Helpful Tips:
* Virutal Environments -> http://sourabhbajaj.com/mac-setup/Python/virtualenv.html
* Anaconda -> https://conda.io/docs/user-guide/tasks/manage-environments.html
* Jupyter Notebooks -> http://jupyter.org
* Plot.ly -> https://plot.ly/python/#maps
* Plot.ly colorscale -> https://plot.ly/python/colorscales/
* Plot.ly map tutorials -> https://plot.ly/python/county-choropleth/

#### Thank You!
* To the audience, for allowing me to share my thoughts
* Calvin, Colleen and the rest of the crew for creating an amazing atmosphere

#### Connect
* LinkedIn: keith-brooks01
* Medium: @kbrook10

### Questions/ Feedback

