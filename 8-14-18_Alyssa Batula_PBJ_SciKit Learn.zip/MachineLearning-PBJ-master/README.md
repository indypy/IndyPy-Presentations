# MachineLearning-PBJ
PBJ Talk for IndyPy

* To create and serve slides from notebook: `$ jupyter nbconvert ML-PBJ.ipynb --to slides --template slides_reveal.tpl --post serve`
* To just create slides: `$ jupyter nbconvert ML-PBJ.ipynb --to slides --template slides_reveal.tpl`
